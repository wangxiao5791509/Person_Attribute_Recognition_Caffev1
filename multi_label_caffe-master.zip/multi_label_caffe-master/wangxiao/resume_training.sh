#!/usr/bin/env sh

# log_filename=/home/wangxiao/Downloads/caffe-master/wangxiao/bvlc_alexnet/log_files/PETA_SPL_Normal_data_.log

# ./build/tools/caffe train \
#     --solver=/home/wangxiao/Downloads/caffe-master/wangxiao/bvlc_alexnet/solver.prototxt \
    
#     --snapshot=/home/wangxiao/Downloads/caffe-master/wangxiao/bvlc_alexnet/tmp_caffe_model/_iter_82000.solverstate 2>&1 | tee -a $log_filename



solver=/home/wangxiao/Downloads/caffe-master/wangxiao/bvlc_alexnet/solver.prototxt

snapshot=/home/wangxiao/Downloads/caffe-master/wangxiao/bvlc_alexnet/all_train_vali_test_data_for_Models/_iter_70000.solverstate

log_filename=/home/wangxiao/Downloads/caffe-master/wangxiao/bvlc_alexnet/log_files/add_unlabeled_data_model_.log

./build/tools/caffe train \
--solver=$solver  \
--snapshot=$snapshot  2>&1 | tee -a $log_filename




 