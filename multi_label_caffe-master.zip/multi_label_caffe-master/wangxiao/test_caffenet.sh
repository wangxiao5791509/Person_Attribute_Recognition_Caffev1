
solver_proto=/home/wangxiao/Downloads/caffe-master/wangxiao/bvlc_alexnet/test.prototxt

weights_solverstate=/home/wangxiao/Downloads/caffe-master/wangxiao/bvlc_alexnet/训练好的model/_iter_74000.caffemodel

log_filename=/home/wangxiao/Downloads/caffe-master/wangxiao/bvlc_alexnet/new_attribute_added_files/filtered_unlabeled_data.log

./build/tools/caffe test \
--model=$solver_proto  --weights=$weights_solverstate  2>&1 | tee -a $log_filename

  