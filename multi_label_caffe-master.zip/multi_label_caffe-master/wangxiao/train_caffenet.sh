
solver_proto=/home/wangxiao/caffe-master/wangxiao/solver.prototxt

weights_solverstate=/home/wangxiao/caffe-master/wangxiao/bvlc_alexnet.caffemodel

log_filename=/home/wangxiao/caffe-master/wangxiao/log_files/_for_Models.log

./build/tools/caffe train \
--solver=$solver_proto  --weights=$weights_solverstate  2>&1 | tee -a $log_filename

